#include <iostream>
#include "TicTacToeBoard.h"
#include "Agent.h"
#include <vector>
#include "QTable.h"
#include <random>
#include <fstream>
using namespace std;

int main(int argc, char* argv[])
{
	Board b;
	QTable QX;
	QTable QY;
	vector<Node*> XHistory;
	vector<Node*> YHistory;
	srand(50);
	Agent X(1);
	Agent Y(2);
	ofstream QXTableFile("QXTable.txt");
	ofstream QYTableFile("QYTable.txt");
	int* XMoves = new int[9];
	int* YMoves = new int[9];
	int TempNum;
	int counter = 0;
	int* TempBoard = new int[9];
	double* TempTable = new double[9];

	counter = 0;
	int move = -1;
	while (counter < 5000)
	{
			XMoves = b.ChooseMoves(b.b);
			move = QX.GetMove(b, b.b, XMoves, XHistory, X, Y);
			b.ApplyMove(move, X);
			if (b.CheckForWinner(X) == X.X)
			{
				cout << "X HAS WON THE GAME" << endl;
				b.ResetBoard();
				counter++;
				QX.UpdateQueueTable(XHistory, 20.0, XHistory.size() - 1, b, X, Y);
				QY.UpdateQueueTable(YHistory, -15, YHistory.size() - 1, b, Y, X);
				XHistory.clear();
				YHistory.clear();
				continue;
			}
			else if (b.CheckIfGameOver())
			{
				b.ResetBoard();
				counter++;
				QX.UpdateQueueTable(XHistory, 45.0, XHistory.size() - 1, b, X, Y);
				QY.UpdateQueueTable(YHistory, 45.0, YHistory.size() - 1, b, Y, X);
				XHistory.clear();
				YHistory.clear();
				continue;
			}

			YMoves = b.ChooseMoves(b.b);
			move = QY.GetMove(b, b.b, YMoves, YHistory, Y, X);
			b.ApplyMove(move, Y);

			if (b.CheckForWinner(Y) == Y.X)
			{
				cout << "Y HAS WON THE GAME!" << endl;
				b.ResetBoard();
				counter++;
				QX.UpdateQueueTable(XHistory, -15, XHistory.size() - 1, b, X, Y);
				QY.UpdateQueueTable(YHistory, 20.0, YHistory.size() - 1, b, Y, X);
				XHistory.clear();
				YHistory.clear();
				continue;
			}
		cout << counter << endl;
	}
	char Player = ' ';

	do
	{
		b.ResetBoard();
		cout << "YOU WILL NOW PLAY THE GAME ENTER IF YOU WANT TO PLAY AS X OR O" << endl;
		cin >> Player;
		int input = -1;

		Agent* Person = new Agent(0);
		int* PersonMoves;
		bool flag = false;

		if (Player == 'x' || Player == 'X')
		{
			Person->X = 1;
		}
		else if (Player == 'o' || Player == 'O')
		{
			Person->X = 2;
		}

		if (Person->X == 2)
		{
			while (!(b.CheckForWinner(X) == X.X) && !(b.CheckForWinner(*Person) == Person->X) && !(b.CheckIfGameOver()))
			{
				flag = false;
				b.PrintBoard();
				XMoves = b.ChooseMoves(b.b);
				move = QX.GetMove(b, b.b, XMoves, X, Person);
				b.ApplyMove(move, X);

				if (b.CheckIfGameOver())
				{
					cout << "UH OH IT ENDED IN A DRAW!!!" << endl;
					break;
				}

				cout << "NOW PICK YOUR Move" << endl;
				b.PrintBoard();
				PersonMoves = b.ChooseMoves(b.b);
				do
				{
					cin >> input;
					input--;
					for (int i = 0; i < 9; i++)
					{
						if (PersonMoves[i] == 1 && input == i)
						{
							flag = true;
						}
					}
					if (flag == false)
					{
						cout << "PICK A VALID MOVE" << endl;
					}

				} while (flag == false);
				b.ApplyMove(input, *Person);
			}
		}
		else
		{
			while (!(b.CheckForWinner(Y) == Y.X) && !(b.CheckForWinner(*Person) == Person->X) && !(b.CheckIfGameOver()))
			{
				flag = false;
				cout << "NOW PICK YOUR MOVE" << endl;
				b.PrintBoard();
				PersonMoves = b.ChooseMoves(b.b);
				do
				{
					cin >> input;
					input--;
					for (int i = 0; i < 9; i++)
					{
						if (PersonMoves[i] == 1 && input == i)
						{
							flag = true;
						}
					}
					if (flag == false)
					{
						cout << "PICK A VALID MOVE" << endl;
					}

				} while (flag == false);

				b.ApplyMove(input, *Person);

				if (b.CheckIfGameOver())
				{
					cout << "UH OH IT ENDED IN A DRAW!!!" << endl;
					break;
				}
				b.PrintBoard();
				YMoves = b.ChooseMoves(b.b);
				move = QY.GetMove(b, b.b, YMoves, Y, Person);
				b.ApplyMove(move, Y);
			}
		}

		if (b.CheckForWinner(*Person) == Person->X)
		{
			cout << "CONGRAGULATIONS YOU WON!!" << endl;
		}
	}while (Player != 'q');

	return 0;
}