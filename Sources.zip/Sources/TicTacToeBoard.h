#pragma once
#include <iostream>
#include "Agent.h"

using namespace std;






class Board
{
public:
	int* b;

	Board()
	{
		b = new int[9];

		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				b[i * 3 + j] = 0;
			}
		}
	}

	int* ChooseMoves(int* board);
	void ApplyMove(int op, Agent ag);
	int* TempBoard(int* board, int op, Agent ag);
	void PrintBoard()
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if (b[i * 3 + j] == 1)
				{
					cout << "X ";
				}
				else if (b[i * 3 + j] == 2)
				{
					cout << "O ";
				}
				else if (b[i * 3 + j] == 0)
				{
					cout << "- ";
				}
			}
			cout << endl;
		}
	}

	int CheckForWinner(Agent ag);

	bool CheckIfGameOver();
	int IfNextMoveWins(int* board, Agent ag);
	void ResetBoard()
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				b[i * 3 + j] = 0;
			}
		}
	}

};
