#pragma once
#include <iostream>




using namespace std;




class Agent
{
public:
	int X;

	Agent(int _X)
	{
		X = _X;
	}

};