#pragma once
#include <iostream>
#include "TicTacToeBoard.h"
#include "Agent.h"
#include <vector>

using namespace std;


struct Node
{
	int* board;
	double* table;
	int Move;
	Node(int* _board)
	{
		board = new int[9];
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				board[i * 3 + j] = _board[i * 3 + j];
			}
		}
		table = new double[9];
		for (int k = 0; k < 9; k++)
		{
			table[k] = 0.0;
		}
		Move = -1;
	}
	Node(int* _board, int _Move)
	{
		board = new int[9];
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				board[i * 3 + j] = _board[i * 3 + j];
			}
		}
		table = new double[9];
		for (int k = 0; k < 9; k++)
		{
			table[k] = 0.0;
		}

		Move = _Move;
	}
};



class QTable
{
public:
	int counter;
	vector<Node*> States;
	
	QTable()
	{
		counter = 0;
	}

	int FindState(int* b);
	int FindState2(int* b);
	int GetMove(Board B, int* b, int* Moves, vector<Node*>& History, Agent ag, Agent OtherAgent);
	int GetMove(Board B, int* b, int* Moves, Agent ag, Agent* OtherAgent);
	void UpdateQueueTable(vector<Node*>& History, double reward, int index, Board& b, Agent ag, Agent OtherAgent);
	int GetRandomMove(int* b, int* move, vector<Node*>& History);
};