#include "TicTacToeBoard.h"

int* Board::ChooseMoves(int* board)
{
    int* Moves = new int[9];

    for (int i = 0; i < 9; i++)
    {
        Moves[i] = 0;
    }

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (board[i * 3 + j] == 0)
            {
                Moves[i * 3 + j] = 1;
            }
        }
    }

    return Moves;

}

void Board::ApplyMove(int op, Agent ag)
{
    if (ag.X == 1)
    {
        b[op] = 1;
    }
    else if (ag.X == 2)
    {
        b[op] = 2;
    }
}

int* Board::TempBoard(int* board, int op, Agent ag)
{
    int* temp = new int[9];

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            temp[i * 3 + j] = board[i * 3 + j];
        }
    }

    if (ag.X == 1)
    {
        temp[op] = 1;
    }
    else if (ag.X == 2)
    {
        temp[op] = 2;
    }

    return temp;
}

int Board::CheckForWinner(Agent ag)
{
    for (int i = 0; i < 3; i++)
    {
        if (b[i * 3 + 0] == ag.X && b[i * 3 + 1] == ag.X && b[i * 3 + 2] == ag.X)
        {
            return ag.X;
        }
    }

    for (int i = 0; i < 3; i++)
    {
        if (b[0 * 3 + i] == ag.X && b[1 * 3 + i] == ag.X && b[2 * 3 + i] == ag.X)
        {
            return ag.X;
        }
    }

    if (b[0] == ag.X && b[4] == ag.X && b[8] == ag.X)
    {
        return ag.X;
    }

    if (b[2] == ag.X && b[4] == ag.X && b[6] == ag.X)
    {
        return ag.X;
    }

    return -1;
}

bool Board::CheckIfGameOver()
{
    bool ret = true;


    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (b[i * 3 + j] == 0)
            {
                ret = false;
            }
        }
    }


    return ret;
}

int Board::IfNextMoveWins(int* board, Agent ag)
{
    int ret = -1;
    for (int i = 0; i < 3; i++)
    {
        if (board[i * 3 + 0] == ag.X && board[i * 3 + 1] == ag.X && board[i * 3 + 2] == 0)
        {
            ret = (i * 3 + 2);
        }
        if (board[i * 3 + 0] == 0 && board[i * 3 + 1] == ag.X && board[i * 3 + 2] == ag.X)
        {
            ret = (i * 3 + 0);
        }
        if (board[i * 3 + 0] == ag.X && board[i * 3 + 2] == ag.X && board[i * 3 + 1] == 0)
        {
            ret = (i * 3 + 1);
        }
    }

    for (int i = 0; i < 3; i++)
    {
        if (board[0 * 3 + i] == ag.X && board[1 * 3 + i] == ag.X && board[2 * 3 + i] == 0)
        {
            ret = (2 * 3 + i);
        }
        if (board[0 * 3 + i] == 0 && board[1 * 3 + i] == ag.X && board[2 * 3 + i] == ag.X)
        {
            ret = (0 * 3 + i);
        }
        if (board[0 * 3 + i] == ag.X && board[1 * 3 + i] == 0 && board[2 * 3 + i] == ag.X)
        {
            ret = (1 * 3 + i);
        }
    }


    if (board[0] == ag.X && board[4] == ag.X && board[8] == 0)
    {
        ret = 8;
    }

    if (board[0] == 0 && board[4] == ag.X && board[8] == ag.X)
    {
        ret = 0;
    }

    if (board[0] == ag.X && board[4] == 0 && board[8] == ag.X)
    {
        ret = 4;
    }


    if (b[2] == ag.X && b[4] == ag.X && b[6] == 0)
    {
        ret = 6;
    }

    if (b[2] == 0 && b[4] == ag.X && b[6] == ag.X)
    {
        ret = 2;
    }

    if (b[2] == ag.X && b[4] == 0 && b[6] == ag.X)
    {
        ret = 4;
    }

    return ret;
}


