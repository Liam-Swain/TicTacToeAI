#include "QTable.h"
#include <random>

#define ALPHA 0.25
#define Y 0.03

int QTable::FindState(int* b)
{
	bool FoundNode = true;
	int i;
	if (States.size() == 0)
	{
		Node* temp = new Node(b);
		States.push_back(temp);
		return -1;
	}

	for (i = 0; i < States.size(); i++)
	{
		FoundNode = true;
		for (int k = 0; k < 3; k++)
		{
			for (int l = 0; l < 3; l++)
			{
				if (States[i]->board[k * 3 + l] != b[k * 3 + l])
				{
					FoundNode = false;
				}
			}
		}

		if (FoundNode == true)
		{
			counter++;
			return i;
		}
	}

	if (FoundNode == false)
	{
		Node* temp = new Node(b);
		States.push_back(temp);
		return -1;
	}

	return -2;
}

int QTable::FindState2(int* b)
{
	bool FoundNode = true;
	int i;
	for (i = 0; i < States.size(); i++)
	{
		FoundNode = true;
		for (int k = 0; k < 3; k++)
		{
			for (int l = 0; l < 3; l++)
			{
				if (States[i]->board[k * 3 + l] != b[k * 3 + l])
				{
					FoundNode = false;
				}
			}
		}

		if (FoundNode == true)
		{
			return i;
		}
	}

	if (FoundNode == false)
	{
		return -1;
	}

	return -2;
}

int QTable::GetMove(Board B, int* b, int* Moves, vector<Node*>& History, Agent ag, Agent OtherAgent)
{


	int Index = FindState(b);
	if (Index == -1)
	{
		int FirstMove = B.IfNextMoveWins(b, ag);
		int SecondMove = B.IfNextMoveWins(b, OtherAgent);
		if (FirstMove != -1)
		{
			cout << FirstMove << endl;
			Node* TempNode = new Node(b, FirstMove);
			History.push_back(TempNode);
			return FirstMove;
		}
		if (SecondMove != -1)
		{
			cout << SecondMove << endl;
			Node* TempNode = new Node(b, SecondMove);
			History.push_back(TempNode);
			return SecondMove;
		}

		int counter = 0;

		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				counter++;
			}
		}
		int* temp = new int[counter];
		counter = 0;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				temp[counter++] = i;
			}
		}

		int op;
		if (counter == 1)
		{
			op = temp[0];
			Node* TempNode = new Node(b, op);
			History.push_back(TempNode);
			return op;
		}

		op = temp[rand() % counter];
		Node* TempNode = new Node(b, op);

		History.push_back(TempNode);

		return op;
	}
	else // we are using a greedy epsilon policy
	{
		int FirstMove = B.IfNextMoveWins(b, ag);
		int SecondMove = B.IfNextMoveWins(b, OtherAgent);
		if (FirstMove != -1)
		{
			cout << FirstMove << endl;
			Node* TempNode = new Node(b, FirstMove);
			History.push_back(TempNode);
			return FirstMove;
		}
		if (SecondMove != -1)
		{
			cout << SecondMove << endl;
			Node* TempNode = new Node(b, SecondMove);
			History.push_back(TempNode);
			return SecondMove;
		}

		int counter = 0;
		double MaxQ = -999999;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				counter++;
			}
		}

		int* temp = new int[counter];
		counter = 0;
		int op;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				temp[counter++] = i;

				if (States[Index]->table[i] > MaxQ)
				{
					MaxQ = States[Index]->table[i];
					op = i;
				}

			}
		}

		if (counter == 1)
		{
			op = temp[0];
			Node* TempNode = new Node(b, op);
			History.push_back(TempNode);
			return op;
		}

		int r = rand() % 10;

		if (r < 7)
		{
			Node* TempNode = new Node(b, op);
			History.push_back(TempNode);
			return op;
		}
		else
		{
			op = temp[rand() % counter];
			Node* TempNode = new Node(b, op);
			History.push_back(TempNode);
			return op;
		}
	}
	
	return -1;
}

int QTable::GetMove(Board B, int* b, int* Moves, Agent ag, Agent* OtherAgent)
{
	int Index = FindState(b);
	if (Index == -1)
	{
		int FirstMove = B.IfNextMoveWins(b, ag);
		int SecondMove = B.IfNextMoveWins(b, *OtherAgent);
		if (FirstMove != -1)
		{
			return FirstMove;
		}
		if (SecondMove != -1)
		{
			return SecondMove;
		}

		int counter = 0;

		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				counter++;
			}
		}
		int* temp = new int[counter];
		counter = 0;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				temp[counter++] = i;
			}
		}

		int op;
		if (counter == 1)
		{
			op = temp[0];
			return op;
		}

		op = temp[rand() % counter];
		return op;
	}
	else // we are using a greedy epsilon policy
	{
		int FirstMove = B.IfNextMoveWins(b, ag);
		int SecondMove = B.IfNextMoveWins(b, *OtherAgent);
		if (FirstMove != -1)
		{
			return FirstMove;
		}
		if (SecondMove != -1)
		{
			return SecondMove;
		}

		int counter = 0;
		double MaxQ = -999999;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				counter++;
			}
		}

		int* temp = new int[counter];
		counter = 0;
		int op;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				temp[counter++] = i;

				if (States[Index]->table[i] > MaxQ)
				{
					MaxQ = States[Index]->table[i];
					op = i;
				}

			}
		}

		if (counter == 1)
		{
			return op;
		}

		return op;
	}

	return -1;
}

void QTable::UpdateQueueTable(vector<Node*>& History, double reward, int index, Board& b, Agent ag, Agent OtherAgent)
{
	int StateIndex = FindState2(History[index]->board);
	double MaxQ = -99999;
	
	if (index == History.size() - 1)
	{
		States[StateIndex]->table[History[index]->Move] = (1 - ALPHA) * States[StateIndex]->table[History[index]->Move] + ALPHA * (reward);
		UpdateQueueTable(History, reward, index - 1, b, ag, OtherAgent);
	}
	else if (index != 0)
	{
		int* Moves = b.ChooseMoves(History[index]->board);
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				int* TempBoard = b.TempBoard(History[index]->board, i, ag);
				int* TempMoves = b.ChooseMoves(TempBoard);
				for (int j = 0; j < 9; j++)
				{
					if (TempMoves[j] == 1)
					{
						int* TempBoard2 = b.TempBoard(TempBoard, j, OtherAgent);
						int TempStateIndex = FindState2(TempBoard2);

						if (TempStateIndex == -1)
						{
							if (MaxQ < 0)
							{
								MaxQ = 0;
							}
						}
						else
						{
							int* TempMoves2 = b.ChooseMoves(TempBoard2);
							for (int k = 0; k < 9; k++)
							{
								if (TempMoves2[k] == 1 && States[TempStateIndex]->table[k] > MaxQ)
								{
									MaxQ = States[TempStateIndex]->table[k];
								}
							}
						}

					}
				}
			}
		}
		States[StateIndex]->table[History[index]->Move] = (1 - ALPHA) * States[StateIndex]->table[History[index]->Move] + ALPHA * (reward + Y * MaxQ);
		UpdateQueueTable(History, reward, index - 1, b, ag, OtherAgent);
	}
	else
	{
		int* Moves = b.ChooseMoves(History[index]->board);
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				int* TempBoard = b.TempBoard(History[index]->board, i, ag);
				int* TempMoves = b.ChooseMoves(TempBoard);
				for (int j = 0; j < 9; j++)
				{
					if (TempMoves[j] == 1)
					{
						int* TempBoard2 = b.TempBoard(TempBoard, j, OtherAgent);
						int TempStateIndex = FindState2(TempBoard2);

						if (TempStateIndex == -1)
						{
							if (MaxQ < 0)
							{
								MaxQ = 0;
							}
						}
						else
						{
							int* TempMoves2 = b.ChooseMoves(TempBoard2);
							for (int k = 0; k < 9; k++)
							{
								if (TempMoves2[k] == 1 && States[TempStateIndex]->table[k] > MaxQ)
								{
									MaxQ = States[TempStateIndex]->table[k];
								}
							}
						}

					}
				}
			}
		}
		States[StateIndex]->table[History[index]->Move] = (1 - ALPHA) * States[StateIndex]->table[History[index]->Move] + ALPHA * (reward + Y * MaxQ);
	}
}

int QTable::GetRandomMove(int* b, int* Moves, vector<Node*>& History)
{
	int Index = FindState(b);
	if (Index == -1)
	{
		int counter = 0;

		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				counter++;
			}
		}
		int* temp = new int[counter];
		counter = 0;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				temp[counter++] = i;
			}
		}

		int op;
		if (counter == 1)
		{
			op = temp[0];
			Node* TempNode = new Node(b, op);
			History.push_back(TempNode);
			return op;
		}

		op = temp[rand() % counter];
		Node* TempNode = new Node(b, op);

		History.push_back(TempNode);

		return op;
	}
	else // we are using a random policy to increase exploration
	{
		int counter = 0;
		double MaxQ = -999999;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				counter++;
			}
		}

		int* temp = new int[counter];
		counter = 0;
		int op;
		for (int i = 0; i < 9; i++)
		{
			if (Moves[i] == 1)
			{
				temp[counter++] = i;

				if (States[Index]->table[i] > MaxQ)
				{
					MaxQ = States[Index]->table[i];
					op = i;
				}

			}
		}

		if (counter == 1)
		{
			op = temp[0];
			Node* TempNode = new Node(b, op);
			History.push_back(TempNode);
			return op;
		}

		op = temp[rand() % counter];
		Node* TempNode = new Node(b, op);
		History.push_back(TempNode);
		return op;
	}

	return -1;
}
